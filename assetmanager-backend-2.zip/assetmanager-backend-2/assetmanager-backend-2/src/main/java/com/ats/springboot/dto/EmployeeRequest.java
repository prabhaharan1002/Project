package com.ats.springboot.dto;

import com.ats.springboot.Model.Employee;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class EmployeeRequest {
		
	private Employee employee;
}
