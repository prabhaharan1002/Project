package com.ats.springboot.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document("Request")
public class Employee {

	@Id
	 private int empId;

    private String empName;
    
    private Long contactNo;

    private String empRole;
    
    private String emailId;
	
	
}
