package com2022.dec.project.Ats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssetTrackingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssetTrackingSystemApplication.class, args);
	}

}
