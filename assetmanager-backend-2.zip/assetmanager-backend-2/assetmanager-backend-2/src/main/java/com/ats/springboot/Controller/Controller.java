package com.ats.springboot.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ats.springboot.EmployeeRepo.EmployeeRepo;
import com.ats.springboot.Emplyoee.Employee;

@RestController
public class Controller {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@PostMapping("/post")
	public Employee postdata(@RequestBody Employee employee) {
		return employeeRepo.save(employee);
	}
}
