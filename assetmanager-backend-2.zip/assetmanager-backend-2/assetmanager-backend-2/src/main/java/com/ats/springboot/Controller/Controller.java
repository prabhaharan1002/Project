package com.ats.springboot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ats.springboot.Model.Employee;
import com.ats.springboot.Repository.EmployeeRepo;

@RestController
public class Controller {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@PostMapping("/postEmployee")
	public Employee postdata(@RequestBody Employee employee) {
		return employeeRepo.save(employee);
	}
	
	
	@GetMapping("/findEmployee")
	public List<Employee> Findall(){
		return employeeRepo.findAll();
	}

	@PutMapping("/employees/update/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable int id, 
			@RequestBody Employee employeeDetails){
		Employee employee = employeeRepo.findById(id).orElseThrow();
		employee.setEmpId(((Employee) employeeRepo).getEmpId());
		Employee updatedEmployee = employeeRepo.save(employeeDetails);
		return ResponseEntity.ok(updatedEmployee);
	}
	
	
	@DeleteMapping("/deleteEmployee/{id}")
	public String delete(@PathVariable int id) {
		 employeeRepo.deleteById(id);
		 return "Employee id is deleted by " +id;
	}
	
}
