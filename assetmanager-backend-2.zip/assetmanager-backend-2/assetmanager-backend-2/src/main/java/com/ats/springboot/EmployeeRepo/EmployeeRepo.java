package com.ats.springboot.EmployeeRepo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ats.springboot.Emplyoee.Employee;

public interface EmployeeRepo extends MongoRepository<Employee,Integer> {

}
