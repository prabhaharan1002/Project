package com.ats.springboot.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ats.springboot.Model.Employee;

public interface EmployeeRepo extends MongoRepository<Employee,Integer> {



}
